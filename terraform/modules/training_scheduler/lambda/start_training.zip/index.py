import boto3
import os

def handler(event, context):
    ec2 = boto3.client('ec2', region_name=os.environ['REGION'])
    instance_id = os.environ['TRAINING_INSTANCE_ID']

    # Check if already running (prevent double-start)
    response = ec2.describe_instances(InstanceIds=[instance_id])
    state = response['Reservations'][0]['Instances'][0]['State']['Name']

    if state == 'stopped':
        ec2.start_instances(InstanceIds=[instance_id])
        print(f"Started training instance {instance_id}")
        return {"status": "started", "instance_id": instance_id}
    else:
        print(f"Instance {instance_id} is {state}, skipping")
        return {"status": "skipped", "state": state}
